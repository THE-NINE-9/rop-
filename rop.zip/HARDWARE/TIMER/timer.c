#include "timer.h"
#include "led.h"
#include "adc.h"
#include "delay.h"
#include "usart.h"
#include "math.h"
double adcx,last_adcx,adcx0=2100;
double err,last_err,out,i;
u32 s,flag=1,ex=1400;
int sp,last_sp;
int sum,out2,sp0;
double errsp,last_errsp,out,i,last_out2;


extern u8 a;
void move1(double out)//��ʱ��

{
	TIM_SetCompare1(TIM2,out);	//�޸ıȽ�ֵ���޸�ռ�ձ� a6
		GPIO_SetBits(GPIOB,GPIO_Pin_12);//�ŵ�
			GPIO_ResetBits(GPIOB,GPIO_Pin_13);
	TIM_SetCompare2(TIM2,499);

}
void move12(double out)
{
	TIM_SetCompare2(TIM2,out);	//�޸ıȽ�ֵ���޸�ռ�ձ�
	GPIO_SetBits(GPIOB,GPIO_Pin_13);//�ŵ�
	GPIO_ResetBits(GPIOB,GPIO_Pin_12);
	TIM_SetCompare1(TIM2,499);	//�޸ıȽ�ֵ���޸�ռ�ձ� a6
}
//??TIM3?????(????????)??????????????,????????????TIM3???,??????????TIM3???,????CNT??(????????????????????)
//????,???????????period?????????????????,??65535??,????65535??????????????
//????,??????????prescaler????,??????,????????????????,??????,??????????????????????,??????,???????????????
//????????????????,?????????????
//??TIM_EncoderMode_TI12??,?????TI1?TI2???????,?????????TIM_ICPolarity_Rising,????TI1?TI2?????????(???)-->?????????
//��������ʱ��

#include "sys.h"

//??????
void encoder_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_ICInitTypeDef TIM_ICInitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_PinAFConfig(GPIOA, GPIO_PinSource6, GPIO_AF_TIM3);    
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_TIM3);
	
	//Specifies the prescaler value used to divide the TIM clock.
	//????,???TIM3?????????A/B????????,???????,???????????????,???????????????????
	TIM_TimeBaseStructure.TIM_Prescaler = 1-1;					//????????1,????
	TIM_TimeBaseStructure.TIM_Period = 65535;					//????????????(?????)??????(???),65535???????,????
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
//	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //????????????,????????TI1?TI2??????
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	
	TIM_ICStructInit(&TIM_ICInitStructure);						//Fills each TIM_ICInitStruct member with its default value
	//???:
	//	void TIM_ICStructInit(TIM_ICInitTypeDef* TIM_ICInitStruct)
	//	{
	//	  /* Set the default configuration */
	//	  TIM_ICInitStruct->TIM_Channel = TIM_Channel_1;
	//	  TIM_ICInitStruct->TIM_ICPolarity = TIM_ICPolarity_Rising;
	//	  TIM_ICInitStruct->TIM_ICSelection = TIM_ICSelection_DirectTI;
	//	  TIM_ICInitStruct->TIM_ICPrescaler = TIM_ICPSC_DIV1;
	//	  TIM_ICInitStruct->TIM_ICFilter = 0x00;
	//	}
	TIM_EncoderInterfaceConfig(TIM3, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising ,TIM_ICPolarity_Rising); //????????,????TI1?TI2???????

	TIM_SetCounter(TIM3, 0);		//?????????
	TIM_Cmd(TIM3, ENABLE);			//??TIM3
}

// ????????
u32 read_cnt(void)
{
	u32 encoder_cnt;
	encoder_cnt = TIM3->CNT;		//?????CNT??,CNT?uint32_t????
	TIM_SetCounter(TIM3, 0);		//????????????????,????????,???????
	return encoder_cnt;				//??????????????
}

//�Ƕȶ�ʱ��

void TIM5_Int_Init(u16 arr,u16 psc) 
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5,ENABLE);  ///ʹ��TIM3ʱ��
	
  TIM_TimeBaseInitStructure.TIM_Period = arr; 	//�Զ���װ��ֵ
	TIM_TimeBaseInitStructure.TIM_Prescaler=psc;  //��ʱ����Ƶ
	TIM_TimeBaseInitStructure.TIM_CounterMode=TIM_CounterMode_Up; //���ϼ���ģʽ
	TIM_TimeBaseInitStructure.TIM_ClockDivision=TIM_CKD_DIV1; //����ʱ�ӷָ�
	
	TIM_TimeBaseInit(TIM5,&TIM_TimeBaseInitStructure);//��ʼ��TIM3
	TIM_ITConfig(TIM5,TIM_IT_Update,ENABLE); //������ʱ��3�����ж�

	NVIC_InitStructure.NVIC_IRQChannel=TIM5_IRQn; //��ʱ��3�ж�
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=0x01; //��ռ���ȼ�2
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=0x02; //�����ȼ�2
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_Cmd(TIM5,ENABLE); //ʹ�ܶ�ʱ��3
}


void TIM5_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM5,TIM_IT_Update)==SET) //����ж�
	{
	 printf("sum2:%d\r\n", sp);
//		out2=2*errsp;
		out2=2.1*errsp+0.01*(errsp+last_errsp);
		last_adcx=adcx;
		adcx=Get_Adc_Average(ADC_Channel_5,10);
  	last_err=err;
	if((adcx>(ex-10))&&(adcx<(ex+10)))
		adcx=1400;
		ex=1400+out2;
	err=adcx-ex;	

		out=2.7*err+0.00001*(err+last_err)+16*(err-last_err);
		if(out>450)
			out=450;
		else if(out<-450)
		{
			out=-450;
		}
		
		if(out>=0)
		{
		 out=450-out;
		 move1(out);
			a=1;
		
		}
		else if(out<0)
		{
			out=-out;
			out=450-out;
			move12(out);
			a=0;
	  
		}
//		s = read_cnt();
//			printf("sum2:%d\r\n", s);
		
		flag++;
		last_sp=sp;
		s = read_cnt();						//???????
		if(s>30000)
		{
			sp0=65536-s;
		  sp0=-sp0;
		}
		else
			sp0=s;
   

		sum=sum+sp0;
	
	  
		if(flag/20==1)
		{
				

			flag=0;
			last_sp=sp;
			
			sp=sum;
//  	  printf("sum2:%d\r\n", sp);
				
					sum=0;
			last_errsp=errsp;
			
			
		  errsp=sp;
			last_out2=out2;
		  out2=5.2*errsp;
//			printf("sout2:%d\r\n", out2);
//			if(fabs(errsp)<15)
//				out2=0;
//		if(out2>=0)
//		{
//		out2=450-out2;
//		 move1(out2);
//			a=1;

//		}
//		else if(out2<0)
//		{
//						out2=-out2;
//      out2=450-out2;
//			move12(out2);
//			a=0;
//	  
//		}
	
}
	}
	TIM_ClearITPendingBit(TIM5,TIM_IT_Update);  //����жϱ�־λ
}
